import React from "react";

const Container = () => {
  return (
    <div>
      <article class="about  active" data-page="about"></article>
    </div>
  );
};

export default Container;
